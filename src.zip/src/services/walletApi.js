import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
export const walletApi = createApi({
  reducerPath: "walletApi",
  baseQuery: fetchBaseQuery({
    baseUrl: "https://lemonchiffon-walrus-503913.hostingersite.com/public/api/",
    prepareHeaders: (headers, { getState }) => {
      const token = getState().auth.token;
      if (token) headers.set("Authorization", `Bearer ${token}`);
      return headers;
    },
  }),
  endpoints: (builder) => ({
    // Get wallet (GET request)
    getwallet: builder.query({
      query: (id) => ({
        url: `customer/transaction/list`,
        method: "GET",
      }),
      providesTags: ["wallet"],
    }),
    addwallet: builder.mutation({
      query: (formData) => ({
        url: `wallet`,
        method: "POST",
        body: formData,
      }),
      invalidatesTags: ["wallet"],
    }),
  }),
});

export const { useGetwalletQuery, useAddwalletMutation } = walletApi;
